
// ch1_1.c 程式, 用來查詢電腦整數型別所佔的記憶體空間

#include <stdio.h>

int main()
{
    printf("size of a short is %d\n", sizeof(short));
    printf("size of a int is %d\n", sizeof(int));
    printf("size of a long is %d\n", sizeof(long));
}
